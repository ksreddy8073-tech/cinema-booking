# Multiplex Cinema Multi-Screen Seat Selection & Dynamic Pricing Engine
Project-44 | 4CTGC2011: OOP using Java & Kotlin | Pure Java 17+ (no external libraries)

## Run
    ./build.sh          # compile into ./out
    ./run-demo.sh       # console simulation (race A vs B on E-12, expiry, 200-thread stress test)
    ./run-server.sh     # REST server + web UI on http://localhost:8080  (optional arg: port)

## Requirement -> code map
| Requirement in the brief                                   | Where |
|------------------------------------------------------------|-------|
| CinemaScreen with 2D array of Seat (row, col, tier, status, price) | CinemaScreen.java (`Seat[][]`), Seat.java, SeatTier, SeatStatus |
| synchronized holdSeat(String seatCode)                      | CinemaScreen.holdSeat(...) |
| Polymorphic pricing: +25% evening, +40% weekend             | PricingStrategy -> RegularPricing / EveningPricing / WeekendPricing; PricingEngine |
| SeatAlreadyBookedException / HoldExpiredException           | custom checked exceptions |
| SeatBookingService synchronises selection requests          | SeatBookingService.java |
| HoldExpiryDaemon releases holds > 300 s                     | HoldExpiryDaemon.java (daemon thread) |
| Simulation workflow (A wins lock, B gets exception, A pays by UPI -> BOOKED) | Main.runDemo() |
| Server in Java                                              | CinemaServer.java (JDK HttpServer + thread pool) |

## REST API
GET /api/screens | GET /api/screens/{id}/seats | GET /api/bookings
POST /api/screens/{id}/hold|pay|release   (form fields: seatCode, userId, upiId)
Status codes: 409 = SeatAlreadyBookedException, 410 = HoldExpiredException.

## Design notes
* Weekend pricing takes precedence over evening (no stacking). Evening = show starts at/after 17:00.
* Seats are lock-protected per screen; the daemon and payment both re-check expiry, so a seat can never be paid after 300 s.
* Seat tiers for an 8-row screen: A-B Classic, C-D Prime, E-F Gold, G-H Recliner (E-12 is Gold, as in the brief).

## Live demo (GitHub Pages)
The folder `docs/` holds a browser version of the booking engine. In the repo go to
Settings -> Pages -> Deploy from a branch -> `main` / `/docs`. The link will be
`https://<your-username>.github.io/<repo-name>/`.

## Deploy the real Java server (shared by all users)
Create a free Web Service on Render (or Railway) from this repo with Runtime = Docker.
The `Dockerfile` builds the project and the server reads the `PORT` environment variable.
