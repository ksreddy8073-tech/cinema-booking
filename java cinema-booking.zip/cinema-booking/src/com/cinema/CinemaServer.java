package com.cinema;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import java.io.IOException;
import java.io.InputStream;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.Instant;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Executors;

/**
 * Java HTTP server (JDK built-in, no libraries). A thread pool serves many users concurrently,
 * which is exactly what exercises the synchronized seat locks.
 *
 *   GET  /                          web UI
 *   GET  /api/screens               list screens + pricing rule
 *   GET  /api/screens/{id}/seats    2D seat layout with live status
 *   POST /api/screens/{id}/hold     form: seatCode, userId            -> 200 | 409 SeatAlreadyBooked
 *   POST /api/screens/{id}/pay      form: seatCode, userId, upiId     -> 200 | 410 HoldExpired | 409
 *   POST /api/screens/{id}/release  form: seatCode, userId
 *   GET  /api/bookings              all confirmed tickets
 */
public class CinemaServer {
    private final SeatBookingService service;
    private final HttpServer server;

    public CinemaServer(SeatBookingService service, int port) throws IOException {
        this.service = service;
        this.server = HttpServer.create(new InetSocketAddress(port), 0);
        server.createContext("/api/", this::handleApi);
        server.createContext("/", this::handleStatic);
        server.setExecutor(Executors.newFixedThreadPool(32));   // concurrent request threads
    }

    public void start() { server.start(); }

    // ---------------- static UI ----------------
    private void handleStatic(HttpExchange ex) throws IOException {
        try (InputStream in = CinemaServer.class.getResourceAsStream("/web/index.html")) {
            if (in == null) { send(ex, 404, "text/plain", "UI not found - run build.sh first"); return; }
            send(ex, 200, "text/html; charset=utf-8", new String(in.readAllBytes(), StandardCharsets.UTF_8));
        }
    }

    // ---------------- REST API ----------------
    private void handleApi(HttpExchange ex) throws IOException {
        String[] p = ex.getRequestURI().getPath().split("/");   // ["", "api", "screens", "1", "hold"]
        String method = ex.getRequestMethod();
        try {
            if (p.length == 3 && p[2].equals("screens") && method.equals("GET")) { json(ex, 200, screensJson()); return; }
            if (p.length == 3 && p[2].equals("bookings") && method.equals("GET")) { json(ex, 200, bookingsJson()); return; }
            if (p.length >= 5 && p[2].equals("screens")) {
                int screenId = Integer.parseInt(p[3]);
                if (p[4].equals("seats") && method.equals("GET")) { json(ex, 200, seatsJson(service.screen(screenId))); return; }
                if (method.equals("POST")) {
                    Map<String, String> f = form(ex);
                    String seat = f.get("seatCode"), user = f.get("userId");
                    if (user == null || user.isBlank()) throw new IllegalArgumentException("userId is required");
                    switch (p[4]) {
                        case "hold" -> {
                            Seat s = service.selectSeat(screenId, seat, user);
                            json(ex, 200, "{\"ok\":true,\"seat\":\"" + s.getCode() + "\",\"price\":" + s.getPrice()
                                    + ",\"holdSeconds\":" + service.screen(screenId).getHoldSeconds() + "}");
                        }
                        case "pay" -> {
                            Booking b = service.confirmPayment(screenId, seat, user, f.get("upiId"));
                            json(ex, 200, "{\"ok\":true,\"bookingId\":\"" + b.bookingId() + "\",\"seat\":\"" + b.seatCode()
                                    + "\",\"amount\":" + b.amount() + ",\"upiTxnId\":\"" + b.upiTxnId() + "\"}");
                        }
                        case "release" -> json(ex, 200, "{\"ok\":" + service.cancelHold(screenId, seat, user) + "}");
                        default -> json(ex, 404, err("NotFound", "Unknown action"));
                    }
                    return;
                }
            }
            json(ex, 404, err("NotFound", "Unknown endpoint"));
        } catch (SeatAlreadyBookedException e) {
            json(ex, 409, err("SeatAlreadyBookedException", e.getMessage()));
        } catch (HoldExpiredException e) {
            json(ex, 410, err("HoldExpiredException", e.getMessage()));
        } catch (IllegalArgumentException e) {
            json(ex, 400, err("BadRequest", e.getMessage()));
        } catch (Exception e) {
            json(ex, 500, err("ServerError", String.valueOf(e.getMessage())));
        }
    }

    // ---------------- JSON builders ----------------
    private String screensJson() {
        StringBuilder sb = new StringBuilder("[");
        boolean first = true;
        for (CinemaScreen s : service.allScreens()) {
            if (!first) sb.append(',');
            first = false;
            sb.append("{\"id\":").append(s.getId())
              .append(",\"name\":\"").append(esc(s.getName())).append('"')
              .append(",\"movie\":\"").append(esc(s.getShow().movie())).append('"')
              .append(",\"showTime\":\"").append(s.getShow().startTime().format(DateTimeFormatter.ofPattern("EEE dd MMM yyyy, HH:mm"))).append('"')
              .append(",\"pricing\":\"").append(esc(s.getPricing().label())).append('"')
              .append(",\"rows\":").append(s.getRows()).append(",\"cols\":").append(s.getCols())
              .append(",\"holdSeconds\":").append(s.getHoldSeconds()).append('}');
        }
        return sb.append(']').toString();
    }

    private String seatsJson(CinemaScreen screen) {
        Seat[][] grid = screen.snapshot();
        Instant now = Instant.now();
        StringBuilder sb = new StringBuilder("{\"rows\":[");
        for (int r = 0; r < grid.length; r++) {
            if (r > 0) sb.append(',');
            sb.append('[');
            for (int c = 0; c < grid[r].length; c++) {
                Seat s = grid[r][c];
                if (c > 0) sb.append(',');
                long left = s.getStatus() == SeatStatus.HELD && s.getHoldExpiresAt() != null
                        ? Math.max(0, Duration.between(now, s.getHoldExpiresAt()).getSeconds()) : 0;
                sb.append("{\"code\":\"").append(s.getCode()).append('"')
                  .append(",\"tier\":\"").append(s.getTier()).append('"')
                  .append(",\"status\":\"").append(s.getStatus()).append('"')
                  .append(",\"price\":").append(s.getPrice())
                  .append(",\"heldBy\":").append(s.getHeldBy() == null ? "null" : "\"" + esc(s.getHeldBy()) + "\"")
                  .append(",\"secondsLeft\":").append(left).append('}');
            }
            sb.append(']');
        }
        return sb.append("]}").toString();
    }

    private String bookingsJson() {
        StringBuilder sb = new StringBuilder("[");
        boolean first = true;
        for (Booking b : service.bookings()) {
            if (!first) sb.append(',');
            first = false;
            sb.append("{\"bookingId\":\"").append(b.bookingId()).append("\",\"screenId\":").append(b.screenId())
              .append(",\"seat\":\"").append(b.seatCode()).append("\",\"user\":\"").append(esc(b.userId()))
              .append("\",\"amount\":").append(b.amount()).append('}');
        }
        return sb.append(']').toString();
    }

    // ---------------- helpers ----------------
    private static String err(String type, String msg) {
        return "{\"ok\":false,\"error\":\"" + type + "\",\"message\":\"" + esc(msg) + "\"}";
    }
    private static String esc(String s) { return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", " "); }

    private static Map<String, String> form(HttpExchange ex) throws IOException {
        String body = new String(ex.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);
        Map<String, String> m = new HashMap<>();
        for (String pair : body.split("&")) {
            if (pair.isEmpty()) continue;
            String[] kv = pair.split("=", 2);
            m.put(URLDecoder.decode(kv[0], StandardCharsets.UTF_8),
                  kv.length > 1 ? URLDecoder.decode(kv[1], StandardCharsets.UTF_8) : "");
        }
        return m;
    }
    private static void json(HttpExchange ex, int code, String body) throws IOException {
        send(ex, code, "application/json; charset=utf-8", body);
    }
    private static void send(HttpExchange ex, int code, String type, String body) throws IOException {
        byte[] b = body.getBytes(StandardCharsets.UTF_8);
        ex.getResponseHeaders().set("Content-Type", type);
        ex.getResponseHeaders().set("Cache-Control", "no-store");
        ex.sendResponseHeaders(code, b.length);
        ex.getResponseBody().write(b);
        ex.close();
    }
}
