package com.cinema;

/** Seating tiers with their base ticket price (INR). */
public enum SeatTier {
    CLASSIC(150.0), PRIME(250.0), GOLD(350.0), RECLINER(500.0);

    private final double basePrice;
    SeatTier(double basePrice) { this.basePrice = basePrice; }
    public double basePrice() { return basePrice; }
}
