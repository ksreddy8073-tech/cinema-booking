package com.cinema;

import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.time.LocalTime;

/**
 * Dynamic tariff engine. Chooses a PricingStrategy at runtime (polymorphism):
 *   Sat/Sun            -> WeekendPricing (+40%)
 *   weekday >= 17:00   -> EveningPricing (+25%)
 *   otherwise          -> RegularPricing
 * Weekend takes precedence over evening (surcharges are not stacked).
 */
public class PricingEngine {
    private static final LocalTime EVENING_START = LocalTime.of(17, 0);

    private final PricingStrategy regular = new RegularPricing();
    private final PricingStrategy evening = new EveningPricing();
    private final PricingStrategy weekend = new WeekendPricing();

    public PricingStrategy strategyFor(LocalDateTime showTime) {
        DayOfWeek d = showTime.getDayOfWeek();
        if (d == DayOfWeek.SATURDAY || d == DayOfWeek.SUNDAY) return weekend;
        if (!showTime.toLocalTime().isBefore(EVENING_START)) return evening;
        return regular;
    }

    public double priceFor(SeatTier tier, LocalDateTime showTime) {
        return Math.round(strategyFor(showTime).apply(tier.basePrice()) * 100.0) / 100.0;
    }
}
