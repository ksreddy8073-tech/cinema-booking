package com.cinema;

/** Weekend screenings: base price + 40%. */
public class WeekendPricing implements PricingStrategy {
    @Override public double apply(double basePrice) { return basePrice * 1.40; }
    @Override public String label() { return "Weekend (+40%)"; }
}
