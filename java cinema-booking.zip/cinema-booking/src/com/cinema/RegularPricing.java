package com.cinema;

/** Daytime weekday shows: no surcharge. */
public class RegularPricing implements PricingStrategy {
    @Override public double apply(double basePrice) { return basePrice; }
    @Override public String label() { return "Regular (base price)"; }
}
