package com.cinema;

import java.util.List;

/**
 * Background daemon thread: periodically scans every screen and releases seats that were held
 * longer than the hold window (300 s by default) without confirmed payment.
 */
public class HoldExpiryDaemon extends Thread {
    private final SeatBookingService service;
    private final long intervalMs;
    private volatile boolean running = true;

    public HoldExpiryDaemon(SeatBookingService service, long intervalMs) {
        super("HoldExpiryDaemon");
        this.service = service;
        this.intervalMs = intervalMs;
        setDaemon(true);   // never blocks JVM shutdown
    }

    @Override public void run() {
        while (running) {
            try {
                for (CinemaScreen screen : service.allScreens()) {
                    List<String> released = screen.releaseExpiredHolds();
                    for (String r : released)
                        Log.info("Screen " + screen.getId() + ": hold expired, seat " + r + " released -> AVAILABLE");
                }
                Thread.sleep(intervalMs);
            } catch (InterruptedException e) {
                return;
            }
        }
    }

    public void shutdown() { running = false; interrupt(); }
}
