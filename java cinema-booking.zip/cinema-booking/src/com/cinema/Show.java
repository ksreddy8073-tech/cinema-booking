package com.cinema;

import java.time.LocalDateTime;

/** A movie screening: what is playing and when. */
public record Show(String movie, LocalDateTime startTime) { }
