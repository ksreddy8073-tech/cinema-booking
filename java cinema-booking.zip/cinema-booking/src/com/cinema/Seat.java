package com.cinema;

import java.time.Instant;

/**
 * One seat of a screen: (row, col, tier, status, price).
 * State is mutated only by CinemaScreen (package-private setters) while it holds the screen lock.
 */
public class Seat {
    private final int row;
    private final int col;
    private final SeatTier tier;
    private final double price;

    private SeatStatus status = SeatStatus.AVAILABLE;
    private String heldBy;          // user who holds / booked the seat
    private Instant holdExpiresAt;  // only meaningful while HELD

    public Seat(int row, int col, SeatTier tier, double price) {
        this.row = row; this.col = col; this.tier = tier; this.price = price;
    }

    /** Defensive copy used for read-only snapshots (UI / reporting). */
    Seat copy() {
        Seat s = new Seat(row, col, tier, price);
        s.status = status; s.heldBy = heldBy; s.holdExpiresAt = holdExpiresAt;
        return s;
    }

    /** Seat code such as "E-12" (row letter + 1-based column). */
    public String getCode() { return codeFor(row, col); }
    public static String codeFor(int row, int col) { return (char) ('A' + row) + "-" + (col + 1); }

    public int getRow() { return row; }
    public int getCol() { return col; }
    public SeatTier getTier() { return tier; }
    public double getPrice() { return price; }
    public SeatStatus getStatus() { return status; }
    public String getHeldBy() { return heldBy; }
    public Instant getHoldExpiresAt() { return holdExpiresAt; }

    void markHeld(String user, Instant expiresAt) { status = SeatStatus.HELD; heldBy = user; holdExpiresAt = expiresAt; }
    void markBooked(String user) { status = SeatStatus.BOOKED; heldBy = user; holdExpiresAt = null; }
    void markAvailable() { status = SeatStatus.AVAILABLE; heldBy = null; holdExpiresAt = null; }

    boolean isHoldExpired(Instant now) {
        return status == SeatStatus.HELD && holdExpiresAt != null && !now.isBefore(holdExpiresAt);
    }

    @Override public String toString() {
        return getCode() + "[" + tier + ", " + status + ", Rs." + price + "]";
    }
}
