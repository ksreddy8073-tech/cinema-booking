package com.cinema;

/** Thrown when payment is attempted after the 300-second hold has expired / been released. */
public class HoldExpiredException extends Exception {
    private final String seatCode;

    public HoldExpiredException(String seatCode) {
        super("Hold on seat " + seatCode + " has expired. Please select the seat again.");
        this.seatCode = seatCode;
    }
    public String getSeatCode() { return seatCode; }
}
