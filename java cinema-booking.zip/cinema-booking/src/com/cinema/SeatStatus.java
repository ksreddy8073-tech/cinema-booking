package com.cinema;

/** Lifecycle of a seat: AVAILABLE -> HELD (5 min payment window) -> BOOKED. */
public enum SeatStatus { AVAILABLE, HELD, BOOKED }
