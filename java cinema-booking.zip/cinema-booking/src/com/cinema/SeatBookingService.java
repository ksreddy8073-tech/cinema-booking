package com.cinema;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Entry point used by the REST layer / simulation. Routes every seat-selection request to the
 * right CinemaScreen (which serialises access to the shared seat state) and records bookings.
 */
public class SeatBookingService {
    private final Map<Integer, CinemaScreen> screens = new ConcurrentHashMap<>();
    private final List<Booking> bookings = new CopyOnWriteArrayList<>();
    private final AtomicInteger bookingCounter = new AtomicInteger(1000);

    public void addScreen(CinemaScreen s) { screens.put(s.getId(), s); }

    public CinemaScreen screen(int id) {
        CinemaScreen s = screens.get(id);
        if (s == null) throw new IllegalArgumentException("No such screen: " + id);
        return s;
    }

    public List<CinemaScreen> allScreens() {
        return screens.values().stream().sorted((a, b) -> Integer.compare(a.getId(), b.getId())).toList();
    }

    public Seat selectSeat(int screenId, String seatCode, String userId) throws SeatAlreadyBookedException {
        try {
            Seat s = screen(screenId).holdSeat(seatCode, userId);
            Log.info(userId + " acquired lock -> " + s.getCode() + " is HELD");
            return s;
        } catch (SeatAlreadyBookedException e) {
            Log.info(userId + " denied -> " + e.getMessage());
            throw e;
        }
    }

    /** Simulated UPI payment confirmation: HELD -> BOOKED and ticket issued. */
    public Booking confirmPayment(int screenId, String seatCode, String userId, String upiId)
            throws HoldExpiredException, SeatAlreadyBookedException {
        if (upiId == null || !upiId.matches("[\\w.\\-]+@[\\w]{2,}"))
            throw new IllegalArgumentException("Invalid UPI id (expected something like name@bank)");
        try {
            Seat s = screen(screenId).confirmBooking(seatCode, userId);
            Booking b = new Booking("BK" + bookingCounter.incrementAndGet(), screenId, s.getCode(), s.getTier(),
                    userId, s.getPrice(), "UPI" + System.nanoTime() % 1_000_000_000L, java.time.Instant.now());
            bookings.add(b);
            Log.info(userId + " paid via " + upiId + " -> " + s.getCode() + " is BOOKED (Rs." + s.getPrice() + ")");
            return b;
        } catch (HoldExpiredException e) {
            Log.info(userId + " payment failed -> " + e.getMessage());
            throw e;
        }
    }

    public boolean cancelHold(int screenId, String seatCode, String userId) {
        boolean ok = screen(screenId).releaseHold(seatCode, userId);
        if (ok) Log.info(userId + " released hold on " + seatCode);
        return ok;
    }

    public List<Booking> bookings() { return List.copyOf(bookings); }
}
