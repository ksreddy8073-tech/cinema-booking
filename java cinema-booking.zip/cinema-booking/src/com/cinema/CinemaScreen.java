package com.cinema;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

/**
 * One screen of the multiplex. Seats live in a 2D array Seat[row][col].
 * Every state-changing method is synchronized on the screen, so concurrent booking threads can
 * never double-book a seat (race-condition prevention on the shared seat lock).
 */
public class CinemaScreen {
    public static final long DEFAULT_HOLD_SECONDS = 300; // 5 minutes

    private final int id;
    private final String name;
    private final Show show;
    private final Seat[][] seats;
    private final long holdSeconds;
    private final PricingStrategy pricing;

    public CinemaScreen(int id, String name, Show show, int rows, int cols,
                        PricingEngine engine, long holdSeconds) {
        this.id = id; this.name = name; this.show = show; this.holdSeconds = holdSeconds;
        this.pricing = engine.strategyFor(show.startTime());
        this.seats = new Seat[rows][cols];
        for (int r = 0; r < rows; r++) {
            SeatTier tier = tierForRow(r, rows);
            double price = engine.priceFor(tier, show.startTime());
            for (int c = 0; c < cols; c++) seats[r][c] = new Seat(r, c, tier, price);
        }
    }

    /** Front rows are cheapest; the last two rows are Recliners. 8 rows: A-B Classic, C-D Prime, E-F Gold, G-H Recliner. */
    private static SeatTier tierForRow(int r, int rows) {
        int band = Math.max(1, rows / 4);
        int idx = Math.min(3, r / band);
        return SeatTier.values()[idx];
    }

    // ---------- lookups ----------
    private Seat find(String seatCode) {
        if (seatCode == null) throw new IllegalArgumentException("Seat code is required");
        String[] p = seatCode.trim().toUpperCase().split("-");
        try {
            int row = p[0].charAt(0) - 'A';
            int col = Integer.parseInt(p[1]) - 1;
            if (p.length == 2 && p[0].length() == 1 && row >= 0 && row < seats.length && col >= 0 && col < seats[0].length)
                return seats[row][col];
        } catch (RuntimeException ignored) { /* fall through */ }
        throw new IllegalArgumentException("Invalid seat code: " + seatCode);
    }

    // ---------- core operations (all guarded by the screen lock) ----------

    /** holdSeat(String seatCode) from the spec; the holder is identified by the calling thread's name. */
    public synchronized Seat holdSeat(String seatCode) throws SeatAlreadyBookedException {
        return holdSeat(seatCode, Thread.currentThread().getName());
    }

    /**
     * Atomically places a hold on a seat for {@code holdSeconds}.
     * @throws SeatAlreadyBookedException if the seat is BOOKED or HELD by someone else
     */
    public synchronized Seat holdSeat(String seatCode, String userId) throws SeatAlreadyBookedException {
        Seat s = find(seatCode);
        Instant now = Instant.now();
        if (s.isHoldExpired(now)) s.markAvailable();          // stale hold: free it first

        switch (s.getStatus()) {
            case BOOKED -> throw new SeatAlreadyBookedException(s.getCode(), SeatStatus.BOOKED);
            case HELD -> {
                if (!userId.equals(s.getHeldBy())) throw new SeatAlreadyBookedException(s.getCode(), SeatStatus.HELD);
                return s.copy();                               // same user re-clicking: idempotent
            }
            default -> s.markHeld(userId, now.plusSeconds(holdSeconds));
        }
        return s.copy();
    }

    /** Called after successful payment: HELD -> BOOKED. */
    public synchronized Seat confirmBooking(String seatCode, String userId)
            throws HoldExpiredException, SeatAlreadyBookedException {
        Seat s = find(seatCode);
        if (s.isHoldExpired(Instant.now())) s.markAvailable();

        switch (s.getStatus()) {
            case AVAILABLE -> throw new HoldExpiredException(s.getCode());
            case BOOKED -> throw new SeatAlreadyBookedException(s.getCode(), SeatStatus.BOOKED);
            default -> {
                if (!userId.equals(s.getHeldBy())) throw new SeatAlreadyBookedException(s.getCode(), SeatStatus.HELD);
                s.markBooked(userId);
            }
        }
        return s.copy();
    }

    /** User abandons the selection: HELD -> AVAILABLE (only the holder may release). */
    public synchronized boolean releaseHold(String seatCode, String userId) {
        Seat s = find(seatCode);
        if (s.getStatus() == SeatStatus.HELD && userId.equals(s.getHeldBy())) { s.markAvailable(); return true; }
        return false;
    }

    /** Used by HoldExpiryDaemon: frees every hold older than holdSeconds. Returns released seat codes. */
    public synchronized List<String> releaseExpiredHolds() {
        List<String> released = new ArrayList<>();
        Instant now = Instant.now();
        for (Seat[] row : seats)
            for (Seat s : row)
                if (s.isHoldExpired(now)) { released.add(s.getCode() + " (was held by " + s.getHeldBy() + ")"); s.markAvailable(); }
        return released;
    }

    /** Consistent, immutable-style copy of the whole 2D layout. */
    public synchronized Seat[][] snapshot() {
        Seat[][] copy = new Seat[seats.length][];
        for (int r = 0; r < seats.length; r++) {
            copy[r] = new Seat[seats[r].length];
            for (int c = 0; c < seats[r].length; c++) copy[r][c] = seats[r][c].copy();
        }
        return copy;
    }

    public synchronized Seat getSeat(String seatCode) { return find(seatCode).copy(); }

    public int getId() { return id; }
    public String getName() { return name; }
    public Show getShow() { return show; }
    public long getHoldSeconds() { return holdSeconds; }
    public PricingStrategy getPricing() { return pricing; }
    public int getRows() { return seats.length; }
    public int getCols() { return seats[0].length; }
}
