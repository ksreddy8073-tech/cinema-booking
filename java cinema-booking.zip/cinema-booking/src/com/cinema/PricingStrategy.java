package com.cinema;

/** Polymorphic pricing rule: each implementation decides how the base price is transformed. */
public interface PricingStrategy {
    double apply(double basePrice);
    String label();
}
