package com.cinema;

/** Thrown when a seat is already BOOKED, or currently HELD by another user. */
public class SeatAlreadyBookedException extends Exception {
    private final String seatCode;
    private final SeatStatus currentStatus;

    public SeatAlreadyBookedException(String seatCode, SeatStatus currentStatus) {
        super("Seat " + seatCode + " is already " + currentStatus);
        this.seatCode = seatCode;
        this.currentStatus = currentStatus;
    }
    public String getSeatCode() { return seatCode; }
    public SeatStatus getCurrentStatus() { return currentStatus; }
}
