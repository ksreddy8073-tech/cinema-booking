package com.cinema;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

/** Tiny thread-aware console logger. */
public final class Log {
    private static final DateTimeFormatter F = DateTimeFormatter.ofPattern("HH:mm:ss.SSS");
    private Log() { }
    public static synchronized void info(String msg) {
        System.out.printf("[%s][%-14s] %s%n", LocalTime.now().format(F), Thread.currentThread().getName(), msg);
    }
}
