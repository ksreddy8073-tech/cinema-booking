package com.cinema;

import java.time.Instant;

/** Confirmed ticket after a successful UPI payment. */
public record Booking(String bookingId, int screenId, String seatCode, SeatTier tier,
                      String userId, double amount, String upiTxnId, Instant bookedAt) { }
