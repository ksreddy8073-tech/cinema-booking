package com.cinema;

/** Evening shows: base price + 25%. */
public class EveningPricing implements PricingStrategy {
    @Override public double apply(double basePrice) { return basePrice * 1.25; }
    @Override public String label() { return "Evening (+25%)"; }
}
