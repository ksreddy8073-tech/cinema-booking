package com.cinema;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Usage:
 *   java -cp out com.cinema.Main server [port]   -> start the REST server + web UI (default 8080)
 *   java -cp out com.cinema.Main demo            -> run the console simulation workflow
 */
public class Main {

    /** Seeds the multiplex: 3 screens, each with a different tariff. */
    static SeatBookingService buildMultiplex(long holdSeconds) {
        PricingEngine engine = new PricingEngine();
        SeatBookingService svc = new SeatBookingService();
        // Thu 29 Oct 2026, 18:00 -> evening (+25%)
        svc.addScreen(new CinemaScreen(1, "Screen 1", new Show("Blockbuster Premiere", LocalDateTime.of(2026, 10, 29, 18, 0)), 8, 14, engine, holdSeconds));
        // Sat 31 Oct 2026, 14:00 -> weekend (+40%)
        svc.addScreen(new CinemaScreen(2, "Screen 2", new Show("Weekend Family Special", LocalDateTime.of(2026, 10, 31, 14, 0)), 8, 12, engine, holdSeconds));
        // Fri 30 Oct 2026, 11:00 -> regular
        svc.addScreen(new CinemaScreen(3, "Screen 3", new Show("Morning Classic", LocalDateTime.of(2026, 10, 30, 11, 0)), 8, 10, engine, holdSeconds));
        return svc;
    }

    public static void main(String[] args) throws Exception {
        String mode = args.length > 0 ? args[0] : "server";
        if (mode.equals("demo")) { runDemo(); return; }

        int port = args.length > 1 ? Integer.parseInt(args[1]) : 8080;
        SeatBookingService svc = buildMultiplex(CinemaScreen.DEFAULT_HOLD_SECONDS);
        new HoldExpiryDaemon(svc, 1000).start();
        new CinemaServer(svc, port).start();
        Log.info("Multiplex booking server running -> http://localhost:" + port);
    }

    // =====================================================================================
    //                              SIMULATION WORKFLOW
    // =====================================================================================
    static void runDemo() throws Exception {
        PricingEngine engine = new PricingEngine();

        System.out.println("\n=== 1. DYNAMIC PRICING (polymorphic tariff rules) ===");
        LocalDateTime[] shows = { LocalDateTime.of(2026, 10, 29, 11, 0), LocalDateTime.of(2026, 10, 29, 18, 0), LocalDateTime.of(2026, 10, 31, 14, 0) };
        for (LocalDateTime t : shows) {
            System.out.printf("%-22s %-22s", t, engine.strategyFor(t).label());
            for (SeatTier tier : SeatTier.values()) System.out.printf(" %s=%.2f", tier, engine.priceFor(tier, t));
            System.out.println();
        }

        System.out.println("\n=== 2. END-TO-END WORKFLOW: User A and User B race for Gold seat E-12 at 18:00:00 ===");
        SeatBookingService svc = buildMultiplex(CinemaScreen.DEFAULT_HOLD_SECONDS);
        HoldExpiryDaemon daemon = new HoldExpiryDaemon(svc, 200);
        daemon.start();

        CountDownLatch startGun = new CountDownLatch(1);
        Thread a = new Thread(() -> userFlow(svc, startGun, "UserA", true), "Thread-UserA");
        Thread b = new Thread(() -> userFlow(svc, startGun, "UserB", false), "Thread-UserB");
        a.start(); b.start();
        startGun.countDown();                // both request E-12 at the same instant
        a.join(); b.join();
        System.out.println("Final E-12 state: " + svc.screen(1).getSeat("E-12"));

        System.out.println("\n=== 3. HOLD EXPIRY: daemon releases an unpaid hold (hold window shortened to 2s for the demo) ===");
        SeatBookingService svc2 = buildMultiplex(2);
        HoldExpiryDaemon daemon2 = new HoldExpiryDaemon(svc2, 200);
        daemon2.start();
        svc2.selectSeat(1, "G-5", "UserC");
        Thread.sleep(3000);                  // UserC never pays
        System.out.println("G-5 after daemon scan : " + svc2.screen(1).getSeat("G-5").getStatus());
        try {
            svc2.confirmPayment(1, "G-5", "UserC", "userc@upi");
        } catch (HoldExpiredException e) {
            System.out.println("Late payment rejected  : HoldExpiredException -> " + e.getMessage());
        }
        daemon2.shutdown();

        System.out.println("\n=== 4. STRESS TEST: 200 threads fight for one seat (F-7) ===");
        CountDownLatch gun = new CountDownLatch(1);
        AtomicInteger won = new AtomicInteger(), rejected = new AtomicInteger();
        List<Thread> ts = new ArrayList<>();
        for (int i = 0; i < 200; i++) {
            final String user = "User" + i;
            Thread t = new Thread(() -> {
                try { gun.await(); svc.screen(1).holdSeat("F-7", user); won.incrementAndGet(); }
                catch (SeatAlreadyBookedException e) { rejected.incrementAndGet(); }
                catch (InterruptedException ignored) { }
            });
            ts.add(t); t.start();
        }
        gun.countDown();
        for (Thread t : ts) t.join();
        System.out.println("Winners: " + won.get() + " | SeatAlreadyBookedException: " + rejected.get()
                + (won.get() == 1 ? "  -> NO double-booking, race condition prevented" : "  -> BUG!"));
        daemon.shutdown();
    }

    private static void userFlow(SeatBookingService svc, CountDownLatch gun, String user, boolean pays) {
        try {
            gun.await();
            svc.selectSeat(1, "E-12", user);          // synchronized holdSeat -> only one thread wins
            if (pays) {
                Thread.sleep(600);                      // stands in for the 60 s UPI payment (time-compressed)
                svc.confirmPayment(1, "E-12", user, user.toLowerCase() + "@okbank");
            }
        } catch (SeatAlreadyBookedException e) {
            Log.info(user + " received SeatAlreadyBookedException (" + e.getCurrentStatus() + ")");
        } catch (Exception e) {
            Log.info(user + " error: " + e);
        }
    }
}
