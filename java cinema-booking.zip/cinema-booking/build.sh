#!/usr/bin/env bash
# Compiles the project into ./out (works with a JDK: javac; falls back to the jdk.compiler module).
set -e
cd "$(dirname "$0")"
rm -rf out && mkdir -p out/web
if command -v javac >/dev/null; then
  javac -d out $(find src -name "*.java")
else
  java -m jdk.compiler/com.sun.tools.javac.Main -d out $(find src -name "*.java")
fi
cp web/index.html out/web/
echo "Build OK -> ./out"
