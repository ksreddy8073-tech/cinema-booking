#!/usr/bin/env bash
cd "$(dirname "$0")"; [ -d out ] || ./build.sh
java -cp out com.cinema.Main server "${1:-8080}"
